<?php /* Template Name: Livedag */ ?>
<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Doorbraak Sessie – Anouk Kievit</title>
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400;1,600&family=Dancing+Script:wght@600;700&family=Jost:wght@300;400;500;600&display=swap" rel="stylesheet" />
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --coral:  #E07035;
      --coral-d:#C05820;
      --blue:   #5B6BB0;
      --blue-d: #4454A0;
      --gold:   #D4A832;
      --gold-bg:#C9A030;
      --purple: #7B7AAA;
      --pink:   #D4A8C8;
      --cream:  #FAF5EE;
      --off:    #FDFAF7;
      --white:  #FFFFFF;
      --text:   #1a1a1a;
      --soft:   #1a1a1a;
      --line:   #DDD5C8;
    }
    html { scroll-behavior: smooth; }
    body { font-family: 'Jost', sans-serif; background: var(--off); color: var(--text); font-size: 17px; line-height: 1.9; }
    img { display: block; width: 100%; height: 100%; object-fit: cover; }

    /* LAYOUT */
    .w { max-width: 1100px; margin: 0 auto; padding: 0 40px; }
    .w--narrow { max-width: 720px; margin: 0 auto; padding: 0 40px; }
    @media (max-width:600px) { .w, .w--narrow { padding: 0 24px; } }

    /* TYPE */
    .eyebrow { display: block; font-size: 10px; letter-spacing: 4px; text-transform: uppercase; font-weight: 600; margin-bottom: 20px; color: var(--soft); }
    .eyebrow--coral { color: var(--coral); }
    .eyebrow--blue  { color: var(--blue); }
    .eyebrow--gold  { color: #8a6520; }
    h2 { font-family: 'Cormorant Garamond', serif; font-size: clamp(38px, 6vw, 72px); font-weight: 300; line-height: 1.08; color: var(--text); margin-bottom: 32px; }
    h2 em { font-style: italic; }
    h2.display { font-size: clamp(52px, 9vw, 110px); line-height: 1; letter-spacing: -1px; }
    p { margin-bottom: 18px; }
    p:last-child { margin-bottom: 0; }

    /* BUTTONS */
    .btn { display: inline-block; padding: 16px 40px; font-family: 'Jost', sans-serif; font-size: 10px; letter-spacing: 3px; text-transform: uppercase; font-weight: 600; text-decoration: none; transition: all .2s ease; cursor: pointer; border: none; border-radius: 2px; }
    .btn--coral { background: var(--coral); color: #fff; }
    .btn--coral:hover { background: var(--coral-d); transform: translateY(-2px); }
    .btn--pink { background: var(--pink); color: var(--text); }
    .btn--pink:hover { background: #C498BA; }
    .btn--outline-dark { background: transparent; border: 1.5px solid var(--text); color: var(--text); }
    .btn--outline-dark:hover { background: var(--text); color: #fff; }
    .btn--outline-white { background: transparent; border: 1.5px solid rgba(255,255,255,.7); color: #fff; }
    .btn--outline-white:hover { background: rgba(255,255,255,.15); }

    /* ═══ URGENCY ═══ */
    .urgency { background: var(--coral); color: #fff; text-align: center; padding: 11px 20px; font-size: 10px; letter-spacing: 3px; text-transform: uppercase; font-weight: 600; }

    /* ═══ HERO — fullbleed foto ═══ */
    .hero { position: relative; min-height: 92vh; display: flex; align-items: center; justify-content: center; text-align: center; overflow: hidden; }
    .hero__bg { position: absolute; inset: 0; background: url('https://anoukkievit.nl/wp-content/uploads/2026/06/Anouk-Kievit_Kramer-Fotografeert-0760.jpg') center top / cover no-repeat; opacity: 0; transition: opacity .5s; }
    .hero__bg.loaded { opacity: 1; }
    .hero__bg::after { content: ''; position: absolute; inset: 0; background: rgba(10,8,6,.65); }
    .hero__content { position: relative; z-index: 1; padding: 80px 40px; display: flex; flex-direction: column; align-items: center; text-align: center; max-width: 860px; }
    .hero__pretitle { font-size: 10px; letter-spacing: 5px; text-transform: uppercase; color: rgba(255,255,255,.65); font-weight: 600; margin-bottom: 28px; display: block; }
    .script { font-family: 'Dancing Script', cursive; font-size: 1.4em; font-weight: 700; display: inline-block; line-height: 1; vertical-align: middle; }
    .about__sig { font-size: 11px; letter-spacing: 4px; text-transform: uppercase; font-weight: 600; color: var(--coral); margin-bottom: 16px; display: block; }
    .hero__h1 { font-family: 'Cormorant Garamond', serif; font-size: clamp(42px, 7vw, 90px); font-weight: 300; line-height: 1.05; color: #fff; margin-bottom: 32px; }
    .hero__h1 em { font-style: italic; color: var(--pink); }
    .hero__sub { font-family: 'Cormorant Garamond', serif; font-size: clamp(18px, 2vw, 24px); font-style: italic; font-weight: 300; color: rgba(255,255,255,.85); max-width: 520px; margin: 0 0 52px; line-height: 1.55; }
    .hero__ctas { display: flex; gap: 14px; flex-wrap: wrap; justify-content: center; }
    @media (max-width:780px) { .hero__content { padding: 60px 28px; } .hero__ctas { flex-direction: column; } .hero__ctas .btn { width: 100%; text-align: center; } }

    /* ═══ STRIP ═══ */
    .strip { background: var(--white); border-bottom: 1px solid var(--line); padding: 24px 40px; }
    .strip__grid { display: flex; flex-wrap: wrap; justify-content: center; }
    .strip__item { text-align: center; padding: 8px 44px; border-right: 1px solid var(--line); }
    .strip__item:last-child { border-right: none; }
    .strip__label { font-size: 9px; letter-spacing: 3px; text-transform: uppercase; color: var(--soft); font-weight: 600; margin-bottom: 3px; }
    .strip__val { font-family: 'Cormorant Garamond', serif; font-size: 19px; color: var(--text); }
    @media (max-width:580px) { .strip__item { border-right: none; width: 50%; } }

    /* ═══ PIJN — al geprobeerd ═══ */
    .pijn { background: var(--off); padding: 100px 0; }
    .pijn__inner { display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: start; }
    @media (max-width:780px) { .pijn__inner { grid-template-columns: 1fr; gap: 48px; } }
    .pijn__photo { position: sticky; top: 80px; }
    .pijn__photo img { border-radius: 2px; height: 600px; }
    .pijn__text h2 { margin-bottom: 12px; }
    .pijn__intro { font-family: 'Cormorant Garamond', serif; font-size: clamp(18px, 2.2vw, 23px); font-style: italic; font-weight: 300; color: var(--soft); line-height: 1.6; margin-bottom: 40px; }
    .pijn__list { list-style: none; }
    .pijn__list li { padding: 22px 0; }
    .pijn__list li:first-child { }
    .pijn__list-num { font-family: 'Cormorant Garamond', serif; font-size: 13px; font-weight: 300; color: var(--coral); letter-spacing: 1px; margin-bottom: 4px; display: block; }
    .pijn__list-title { font-family: 'Cormorant Garamond', serif; font-size: clamp(18px, 2vw, 22px); font-weight: 400; color: var(--text); margin-bottom: 6px; }
    .pijn__list-body { font-size: 16px; color: var(--soft); line-height: 1.75; }
    .pijn__close { margin-top: 40px; font-family: 'Cormorant Garamond', serif; font-size: clamp(20px, 2.5vw, 26px); font-style: italic; font-weight: 300; color: var(--text); line-height: 1.5; }
    .pijn__close strong { font-style: normal; color: var(--coral); }

    /* ═══ CORAL FULLBLEED ═══ */
    .band { padding: 96px 40px; text-align: center; }
    .band--coral { background: var(--coral); }
    .band--coral .band__text { color: #fff; }
    .band--coral .band__attr { color: rgba(255,255,255,.55); }
    .band--gold   { background: var(--gold-bg); }
    .band--gold .band__text { color: var(--text); }
    .band--gold .band__attr { color: rgba(26,26,26,.4); }
    .band--pink   { background: var(--pink); }
    .band--pink .band__text { color: var(--text); }
    .band--blue   { background: var(--blue); }
    .band--blue .band__text { color: #fff; }
    .band__text { font-family: 'Cormorant Garamond', serif; font-size: clamp(28px, 5vw, 58px); font-weight: 300; font-style: italic; line-height: 1.3; max-width: 820px; margin: 0 auto 16px; }
    .band__attr  { font-size: 10px; letter-spacing: 3px; text-transform: uppercase; display: block; margin-top: 16px; }

    /* ═══ VERLANGEN ═══ */
    .verlangen { background: var(--white); padding: 100px 0; }
    .verlangen__header { text-align: center; max-width: 640px; margin: 0 auto 72px; }
    .verlangen__header p { font-size: 17px; color: var(--soft); line-height: 1.8; }
    .verlangen__header h2 { color: var(--text); font-size: clamp(36px, 5vw, 64px); font-weight: 300; line-height: 1.1; letter-spacing: -0.5px; }
    .verlangen__header h2 em { color: var(--blue); font-style: italic; }
    .verlangen__header .eyebrow { color: var(--blue); }
    .verlangen__grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1px; background: var(--blue); border: 1px solid var(--blue); }
    @media (max-width:640px) { .verlangen__grid { grid-template-columns: 1fr; } }
    .verlangen__card { background: var(--white); padding: 48px 44px; }
    .verlangen__card:nth-child(odd) { background: var(--off); }
    .verlangen__card-num { font-family: 'Cormorant Garamond', serif; font-size: 11px; font-weight: 300; color: var(--coral); letter-spacing: 2px; margin-bottom: 16px; display: block; }
    .verlangen__card-q { font-family: 'Cormorant Garamond', serif; font-size: clamp(20px, 2.2vw, 25px); font-style: italic; font-weight: 300; color: var(--text); line-height: 1.4; margin-bottom: 14px; }
    .verlangen__card-body { font-size: 16px; color: var(--soft); line-height: 1.75; }

    /* ═══ WATALS — photo fullbleed sections ═══ */
    .watals-intro { background: var(--off); padding: 80px 0 0; text-align: center; }
    .watals-intro h2 { margin-bottom: 16px; }
    .watals-intro p { font-size: 17px; color: var(--soft); max-width: 520px; margin: 0 auto; }

    .watals__row { display: grid; grid-template-columns: 1fr 1fr; min-height: 520px; }
    @media (max-width:720px) { .watals__row { grid-template-columns: 1fr; } }
    .watals__row--flip .watals__photo { order: 2; }
    .watals__row--flip .watals__copy  { order: 1; }
    @media (max-width:720px) { .watals__row--flip .watals__photo, .watals__row--flip .watals__copy { order: unset; } }
    .watals__photo { position: relative; min-height: 420px; }
    .watals__photo img { position: absolute; inset: 0; }
    .watals__copy { background: var(--off); display: flex; align-items: center; padding: 64px 56px; }
    @media (max-width:720px) { .watals__copy { padding: 48px 32px; } }
    .watals__copy-tag { font-size: 9px; letter-spacing: 3px; text-transform: uppercase; font-weight: 700; color: var(--coral); margin-bottom: 14px; display: block; }
    .watals__copy h3 { font-family: 'Cormorant Garamond', serif; font-size: clamp(26px, 3vw, 38px); font-weight: 300; line-height: 1.2; color: var(--text); margin-bottom: 16px; }
    .watals__copy h3 em { font-style: italic; color: var(--coral); }
    .watals__copy p { font-size: 15px; color: var(--soft); line-height: 1.8; }

    /* ═══ VERSIE BAND ═══ */
    .versie { background: var(--purple); padding: 96px 40px; }
    .versie__inner { display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center; max-width: 1100px; margin: 0 auto; }
    @media (max-width:760px) { .versie__inner { grid-template-columns: 1fr; gap: 40px; } }
    .versie__photo { border-radius: 2px; overflow: hidden; }
    .versie__photo img { height: 560px; border-radius: 2px; }
    .versie__text .eyebrow { color: rgba(255,255,255,.65); }
    .versie__text h2 { color: #fff; margin-bottom: 24px; }
    .versie__text h2 em { color: var(--pink); font-style: italic; }
    .versie__text p { font-size: 16px; color: rgba(255,255,255,.85); line-height: 1.85; margin-bottom: 16px; }
    .versie__quote { margin: 28px 0; font-family: 'Cormorant Garamond', serif; font-size: 22px; font-style: italic; color: rgba(255,255,255,.9); line-height: 1.45; }

    /* ═══ VOOR WIE ═══ */
    .voor-wie { background: var(--white); padding: 100px 0; }
    .voor-wie__inner { display: grid; grid-template-columns: 1fr 2fr; gap: 80px; align-items: start; }
    @media (max-width:760px) { .voor-wie__inner { grid-template-columns: 1fr; gap: 40px; } }
    .voor-wie__list { list-style: none; }
    .voor-wie__list li { padding: 18px 0; font-size: 16px; line-height: 1.7; color: var(--text); display: flex; gap: 16px; align-items: flex-start; }
    .voor-wie__list li:first-child { }
    .voor-wie__list li::before { content: '→'; color: var(--coral); flex-shrink: 0; font-weight: 600; margin-top: 2px; }

    /* ═══ PRICING ═══ */
    .pricing { background: var(--off); padding: 100px 0; }
    .pricing__header { text-align: center; margin-bottom: 72px; }
    .pricing__header p { font-size: 16px; color: var(--soft); max-width: 460px; margin: 12px auto 0; }
    .pricing__cards { display: grid; grid-template-columns: 1fr 1fr; gap: 2px; background: var(--line); border: 1px solid var(--line); }
    @media (max-width:640px) { .pricing__cards { grid-template-columns: 1fr; } }
    .price-card { background: var(--white); padding: 52px 44px; position: relative; }
    .price-card--featured { background: var(--cream); }
    .price-card__badge { display: inline-block; background: var(--coral); color: #fff; font-size: 9px; letter-spacing: 2px; text-transform: uppercase; font-weight: 700; padding: 4px 14px; border-radius: 2px; margin-bottom: 16px; }
    .price-card__type { font-size: 9px; letter-spacing: 3px; text-transform: uppercase; font-weight: 700; color: var(--soft); margin-bottom: 6px; }
    .price-card__name { font-family: 'Cormorant Garamond', serif; font-size: 36px; font-weight: 300; color: var(--text); margin-bottom: 8px; }
    .price-card__tagline { font-size: 14px; font-style: italic; color: var(--soft); margin-bottom: 28px; padding-bottom: 28px; border-bottom: 1px solid var(--line); line-height: 1.6; }
    .price-card__price { font-family: 'Cormorant Garamond', serif; font-size: 64px; font-weight: 300; color: var(--coral); line-height: 1; margin: 0 0 4px; }
    .price-card__note { font-size: 12px; color: var(--soft); margin-bottom: 28px; }
    .price-card__includes { list-style: none; margin-bottom: 36px; }
    .price-card__includes li { font-size: 14px; padding: 10px 0; display: flex; gap: 10px; color: var(--text); align-items: flex-start; }
    .price-card__includes li::before { content: '✓'; color: var(--coral); flex-shrink: 0; font-weight: 700; }
    .price-card .btn { width: 100%; text-align: center; }

    /* ═══ ABOUT ═══ */
    .about { background: var(--white); padding: 100px 0; }
    .about__inner { display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center; }
    @media (max-width:740px) { .about__inner { grid-template-columns: 1fr; gap: 48px; } }
    .about__photo { position: relative; display: flex; align-items: center; justify-content: center; }
    .about__circles { position: relative; width: 420px; height: 520px; flex-shrink: 0; margin: 0 auto; }
    .about__circles::before { content: none; }
    .about__circles::after  { content: none; }
    .about__circle-img { position: absolute; inset: 0; margin: auto; width: 380px; height: 480px; border-radius: 4px; overflow: hidden; z-index: 1; }
    .about__circle-img img { width: 100%; height: 100%; object-fit: cover; border-radius: 4px; }
    @media (max-width:740px) { .about__circles { width: 100%; height: 380px; } .about__circle-img { width: 100%; height: 360px; } }
    .about__text p { font-size: 16px; color: var(--soft); line-height: 1.85; }
    .about__pullquote { margin: 28px 0; font-family: 'Cormorant Garamond', serif; font-size: 22px; font-style: italic; color: var(--text); line-height: 1.45; }

    /* ═══ FAQ ═══ */
    .faq { background: var(--white); padding: 100px 0; }
    .faq__grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0 80px; }
    @media (max-width:700px) { .faq__grid { grid-template-columns: 1fr; } }
    .faq__item { padding: 24px 0; }
    .faq__item:first-child { }
    .faq__q { font-family: 'Cormorant Garamond', serif; font-size: 21px; color: var(--text); margin-bottom: 8px; }
    .faq__a { font-size: 14px; color: var(--soft); line-height: 1.8; }

    /* ═══ FINAL CTA — photo bg ═══ */
    .final-cta { position: relative; min-height: 80vh; display: flex; align-items: center; justify-content: center; text-align: center; overflow: hidden; }
    .final-cta__bg { position: absolute; inset: 0; background: url('https://anoukkievit.nl/wp-content/uploads/2026/06/Anouk-Kievit_Kramer-Fotografeert-0744.jpg') center bottom / cover no-repeat; }
    .final-cta__bg::after { content: ''; position: absolute; inset: 0; background: rgba(15,10,5,.6); }
    .final-cta__content { position: relative; z-index: 1; padding: 80px 40px; max-width: 760px; }
    .final-cta__content h2 { font-family: 'Cormorant Garamond', serif; font-size: clamp(44px, 8vw, 96px); font-weight: 300; line-height: 1.05; color: #fff; margin-bottom: 24px; }
    .final-cta__content h2 em { font-style: italic; color: var(--coral); }
    .final-cta__content p { font-size: 17px; color: rgba(255,255,255,.8); max-width: 460px; margin: 0 auto 44px; line-height: 1.75; font-weight: 300; }

    /* ═══ INZICHT SECTIE ═══ */
    .inzicht { background: var(--off); padding: 96px 40px; text-align: center; }
    .inzicht__inner { max-width: 760px; margin: 0 auto; }
    .inzicht__body { font-family: 'Cormorant Garamond', serif; font-size: clamp(22px, 3vw, 34px); font-weight: 300; line-height: 1.65; color: var(--text); margin-bottom: 32px; }
    .inzicht__body em { font-style: italic; color: var(--coral); }
    .inzicht__vraag { font-family: 'Cormorant Garamond', serif; font-size: clamp(30px, 4.5vw, 56px); font-style: italic; font-weight: 300; color: var(--text); line-height: 1.3; padding-top: 40px; margin-top: 16px; }

    /* ═══ FOOTER ═══ */
    footer { background: var(--coral-d); color: rgba(255,255,255,.7); text-align: center; padding: 18px 28px; font-size: 11px; letter-spacing: 1.5px; }

    /* ═══ MOBIEL ═══ */
    @media (max-width:780px) {
      /* Hero */
      .hero { grid-template-columns: 1fr; min-height: auto; }
      .hero__bg { min-height: 55vw; order: -1; }
      .hero__content { padding: 48px 28px; }
      .hero__ctas { flex-direction: column; }
      .hero__ctas .btn { text-align: center; width: 100%; }

      /* Secties */
      .pijn { padding: 64px 0; }
      .pijn__photo { display: none; }
      .pijn__inner { grid-template-columns: 1fr; gap: 0; }

      /* Bands */
      .band { padding: 60px 28px; }

      /* Verlangen */
      .verlangen { padding: 64px 0; }
      .verlangen__header { padding: 0 24px; margin-bottom: 40px; }
      .verlangen__card { padding: 36px 28px; }
      .verlangen__grid { grid-template-columns: 1fr; }

      /* Versie */
      .versie { padding: 64px 24px; }
      .versie__inner { grid-template-columns: 1fr; gap: 32px; }
      .versie__photo img { height: 300px; }

      /* Voor wie */
      .voor-wie { padding: 64px 0; }
      .voor-wie__inner { grid-template-columns: 1fr; gap: 28px; }

      /* Pricing */
      .pricing { padding: 64px 0; }
      .pricing__cards { grid-template-columns: 1fr; }
      .price-card { padding: 40px 28px; }

      /* About */
      .about { padding: 64px 0; }
      .about__inner { grid-template-columns: 1fr; gap: 36px; }
      .about__circles { width: 100%; height: 320px; }
      .about__circle-img { width: 100%; height: 300px; }

      /* FAQ */
      .faq { padding: 64px 0; }
      .faq__grid { grid-template-columns: 1fr; gap: 0; }

      /* Inzicht */
      .inzicht { padding: 64px 28px; }

      /* Final CTA */
      .final-cta { min-height: 60vh; }
      .final-cta__content { padding: 60px 28px; }

      /* Strip */
      .strip { padding: 16px 24px; }
      .strip__item { padding: 8px 20px; width: 50%; border-right: none; }
    }
    footer a { color: #fff; text-decoration: none; }
  </style>
</head>
<body>

<script>
window.addEventListener('DOMContentLoaded', function(){
  var bg = document.querySelector('.hero__bg');
  if(bg){ var img=new Image(); img.onload=function(){ bg.classList.add('loaded'); }; img.src=bg.style.backgroundImage?'':' ';
  bg.classList.add('loaded'); }
});
</script>

<!-- ═══ HERO ═══ -->
<section class="hero">
  <div class="hero__content">
    <span class="hero__pretitle">Anouk Kievit</span>
    <h1 class="hero__h1">
      Je draait omzet.<br>Je bedrijf loopt.<br><em>Waarom houd jij jezelf<br>dan nog steeds klein?</em>
    </h1>
    <p class="hero__sub">
      Je hebt geïnvesteerd in strategie, coaches en trajecten. Toch staat je bedrijf niet waar jij weet dat het hoort. Het ligt niet aan je kennis.
    </p>
    <div class="hero__ctas">
      <a href="#investering" class="btn btn--pink">Ik wil dit doorbreken →</a>
      <a href="#verlangen" class="btn btn--outline-white">Wat is er mogelijk?</a>
    </div>
  </div>
  <div class="hero__bg"></div>
</section>


<!-- ═══ HERKENNING ═══ -->
<section class="pijn">
  <div class="w">
    <div class="pijn__inner">

      <div class="pijn__photo">
        <img src="https://anoukkievit.nl/wp-content/uploads/2026/06/Anouk-Kievit_Kramer-Fotografeert-0740.jpg" alt="Anouk Kievit" />
      </div>

      <div class="pijn__text">
        <span class="eyebrow eyebrow--coral">Herken jij dit</span>
        <h2>Je bent niet moe<br>van het ondernemen.<br><em>Je bent moe van<br>jezelf tegenhouden.</em></h2>
        <p class="pijn__intro">
          Je weet wat je moet doen. Je bent niet naïef, je bent niet lui — je hebt al zoveel gedaan om verder te komen. En toch rijdt je al jaren met de handrem erop, zonder dat je precies kunt zeggen waarom.
        </p>

        <ul class="pijn__list">
          <li>
            <span class="pijn__list-num">01</span>
            <div class="pijn__list-title">Je staat bijna altijd 'aan'.</div>
            <div class="pijn__list-body">Je draait omzet en je klanten zijn tevreden, maar rust voelt als iets wat je nog moet verdienen. Je kunt het simpelweg niet uitzetten, hoe graag je dat ook wilt.</div>
          </li>
          <li>
            <span class="pijn__list-num">02</span>
            <div class="pijn__list-title">Je houdt jezelf online kleiner dan je werkelijk bent.</div>
            <div class="pijn__list-body">De post staat klaar. De prijs staat klaar. Maar je klikt niet op verzenden — niet omdat je niets te zeggen hebt, maar omdat er een stem is die fluistert dat het nog niet goed genoeg is.</div>
          </li>
          <li>
            <span class="pijn__list-num">03</span>
            <div class="pijn__list-title">Je hebt alles geprobeerd en blijft zoeken.</div>
            <div class="pijn__list-body">Businesscoaching, nieuwe strategie, boeken, mindset — de buitenkant klopt allang. Maar vanbinnen voelt ondernemen zwaarder dan het zou moeten, en dat frustreert je, want je weet dat er meer in je zit.</div>
          </li>
          <li>
            <span class="pijn__list-num">04</span>
            <div class="pijn__list-title">Je weet dat de oplossing ergens anders ligt.</div>
            <div class="pijn__list-body">Niet in een nieuwe cursus, niet in een nieuw plan. Je voelt het — er is een laag die je nog niet hebt aangeraakt. Dat is precies de laag waar wij naartoe gaan.</div>
          </li>
        </ul>

        <p class="pijn__close">
          Stel jezelf eens eerlijk de vraag: als de komende twaalf maanden niets verandert, <strong>wat betekent dat dan voor jou?</strong> Dat is de vraag die de meeste ondernemers liever niet beantwoorden. Maar het is ook de vraag die alles verandert.
        </p>
      </div>

    </div>
  </div>
</section>


<!-- CORAL BAND -->
<div class="band band--coral">
  <p class="band__text">"Je houdt jezelf niet klein omdat je zwak bent. Je houdt jezelf klein omdat je gelooft dat het zo hoort."</p>
  <cite class="band__attr">Anouk Kievit</cite>
</div>


<!-- ═══ WAT JE EIGENLIJK WIL ═══ -->
<section class="verlangen" id="verlangen">
  <div class="w">
    <div class="verlangen__header">
      <span class="eyebrow eyebrow--blue">Wat er verandert</span>
      <h2>Echte rust.<br>Echt vertrouwen.<br><em>Echt vrij ondernemen.</em></h2>
      <p>Niet harder werken, niet een nieuwe aanpak. Gewoon ondernemen vanuit wie je werkelijk bent — zonder dat het je zoveel kost als het nu doet.</p>
    </div>

    <div class="verlangen__grid">
      <div class="verlangen__card">
        <span class="verlangen__card-num">01</span>
        <p class="verlangen__card-q">"Ik wil echte mentale rust. Niet de rust die ik verdien. Gewoon rust."</p>
        <p class="verlangen__card-body">Niet meer constant 'aan' staan, niet meer malen na elke beslissing. Gewoon aanwezig zijn in je werk, bij de mensen om je heen en bij jezelf — zonder dat het energie kost die je niet hebt.</p>
      </div>
      <div class="verlangen__card">
        <span class="verlangen__card-num">02</span>
        <p class="verlangen__card-q">"Ik wil mijn prijs noemen zonder me daarna te verontschuldigen."</p>
        <p class="verlangen__card-body">Geen snelle uitleg erachteraan, geen halve nacht wakker liggen of het wel goed voelde. Gewoon zeggen wat het is, met de zekerheid van iemand die weet wat ze waard is — en daarna zwijgen.</p>
      </div>
      <div class="verlangen__card">
        <span class="verlangen__card-num">03</span>
        <p class="verlangen__card-q">"Ik wil online laten zien wie ik werkelijk ben. Niet de gefilterde versie."</p>
        <p class="verlangen__card-body">Op 'Plaatsen' drukken zonder hem daarna drie keer te verwijderen. Zichtbaar zijn als de ondernemer die je al bent — niet de versie die staat te wachten tot het allemaal goed genoeg is.</p>
      </div>
      <div class="verlangen__card">
        <span class="verlangen__card-num">04</span>
        <p class="verlangen__card-q">"Ik wil beslissen vanuit vertrouwen, niet vanuit angst dat ik me vergis."</p>
        <p class="verlangen__card-body">Sneller, lichter, zonder de keuze daarna nog drie dagen te analyseren. Kiezen vanuit wie je bent en gewoon verder gaan — dat is wat er mogelijk is als de rem er eindelijk af gaat.</p>
      </div>
    </div>
  </div>
</section>


<!-- ═══ PLOT TWIST ═══ -->
<section class="versie">
  <div class="versie__inner">
    <div class="versie__photo">
      <img src="https://anoukkievit.nl/wp-content/uploads/2026/06/Anouk-Kievit_Kramer-Fotografeert-0850.jpg" alt="Anouk Kievit" />
    </div>
    <div class="versie__text">
      <span class="eyebrow">Je hebt geen nieuw traject nodig</span>
      <h2>Je bent de<br>bottleneck in<br><em>je eigen bedrijf.</em></h2>
      <p>Dat is niet erg — het is gewoon de waarheid. En het is ook het beste nieuws dat je vandaag kunt horen, want als jij de bottleneck bent, dan ben jij ook de oplossing. Niet door meer te leren of harder te werken, maar door te zien welke overtuiging onzichtbaar alles stuurt.</p>
      <div class="versie__quote">
        Je kiest nooit op basis van feiten. Je kiest op basis van wat voor jou waar voelt — en wat waar voelt, wordt bepaald door overtuigingen die je ooit hebt aangenomen en nooit meer hebt onderzocht.
      </div>
      <p>Één gesprek is genoeg om dat te zien. En daarna kijk je nooit meer hetzelfde naar de keuzes die je maakt.</p>
      <p style="margin-top:32px;"><a href="#investering" class="btn btn--outline-white">Ik wil dit nu aanpakken →</a></p>
    </div>
  </div>
</section>


<!-- ═══ VOOR WIE ═══ -->
<section class="voor-wie">
  <div class="w">
    <div class="voor-wie__inner">
      <div>
        <span class="eyebrow eyebrow--coral">Is dit voor jou</span>
        <h2>Dit is voor<br>gevestigde<br><em>ondernemers.</em></h2>
        <p style="font-size:15px;color:var(--soft);line-height:1.85;margin-top:16px;">Niet voor starters. Voor ondernemers die al weten hoe het werkt — maar voelen dat er een laag is die ze nog niet hebben aangeraakt.</p>
      </div>
      <div>
        <ul class="voor-wie__list">
          <li>Je draait omzet en je bedrijf loopt, maar de groei stagneert of ondernemen kost je meer energie dan het zou moeten — en je weet dat dat niet normaal hoeft te zijn.</li>
          <li>Je hebt geïnvesteerd in coaches, cursussen en trajecten. Je weet wat je moet doen. Toch doe je het niet, en je weet zelf ook niet precies waarom.</li>
          <li>Je staat bijna altijd 'aan'. Rust voelt als iets wat je verdient, niet als iets wat er gewoon mag zijn — en je bent het moe om dat met jezelf te onderhandelen.</li>
          <li>Je weet dat er meer in je zit, en dat frustreert je. De buitenkant klopt allang, maar vanbinnen rijdt je nog steeds met de handrem erop.</li>
          <li>Je voelt dat de oplossing ergens anders ligt dan strategie — en je bent klaar om dat nu echt te onderzoeken, zonder omwegen.</li>
        </ul>
        <div style="margin-top:40px;padding:28px 32px;background:var(--cream);">
          <p style="font-size:13px;letter-spacing:3px;text-transform:uppercase;font-weight:700;color:var(--soft);margin-bottom:14px;">Dit is niet voor jou als</p>
          <p style="font-size:15px;color:var(--soft);line-height:1.85;margin:0;">Je net begint en nog geen klanten hebt, of als je twijfelt of persoonlijke groei überhaupt iets voor jou is. Dit werk vraagt eerlijkheid en echte bereidheid — zonder dat heeft het geen zin om te beginnen.</p>
        </div>
      </div>
    </div>
  </div>
</section>


<!-- GOLD BAND -->
<div class="band band--gold">
  <p class="band__text">"Je kiest nooit op basis van feiten. Je kiest op basis van wat voor jou waar voelt."</p>
  <cite class="band__attr">Anouk Kievit</cite>
</div>


<!-- ═══ INZICHT ═══ -->
<section class="inzicht">
  <div class="inzicht__inner">
    <p class="inzicht__body">
      Wat er speelt heeft niets te maken met een gebrek aan kennis of discipline. Het zit in de overtuigingen waarmee je jarenlang hebt geleefd — overtuigingen die ooit logisch waren, maar vandaag <em>ongemerkt al jouw keuzes bepalen.</em> Niet omdat je ze bewust kiest, maar omdat je ze nooit hebt onderzocht.
    </p>
    <p class="inzicht__vraag">Als je voelt dat het niet meer<br>aan de strategie ligt —<br>dan is dit jouw volgende stap.</p>
  </div>
</section>


<!-- ═══ PRICING ═══ -->
<section class="pricing" id="investering">
  <div class="w">
    <div class="pricing__header">
      <span class="eyebrow eyebrow--coral">Jouw investering</span>
      <h2>Twee opties.<br><em>Eén resultaat.</em></h2>
      <p>Jij die vrijer kiest, sneller beslist en onderneemt zonder dat het je zoveel kost als nu.</p>
    </div>

    <div class="pricing__cards">
      <div class="price-card">
        <div class="price-card__type">Online · 60 minuten</div>
        <div class="price-card__name">De Doorbraak Sessie</div>
        <div class="price-card__tagline">In één gesprek ontdekken we welke overtuiging jouw keuzes bepaalt — en wat er verandert als je hem niet meer gelooft.</div>
        <div class="price-card__price">€125</div>
        <div class="price-card__note">60 minuten · online · datum flexibel</div>
        <ul class="price-card__includes">
          <li>Online sessie met Anouk</li>
          <li>Jouw kernovertuiging gevonden en onderzocht</li>
          <li>Concreet vertrekpunt om vrijer te kiezen</li>
          <li>Datum flexibel in te plannen</li>
        </ul>
        <a href="https://anoukkievit.membirds.com/checkout/online-sessie-90-min" class="btn btn--outline-dark">Ik boek de sessie</a>
      </div>

      <div class="price-card price-card--featured">
        <div class="price-card__badge">Meest diepgaand</div>
        <div class="price-card__type">Live · 2,5 uur</div>
        <div class="price-card__name">De Doorbraak Dag</div>
        <div class="price-card__tagline">2,5 uur live samen. De ruimte en diepgang die een online sessie niet kan bieden — hier verschuift er iets wat je voelt, niet alleen begrijpt.</div>
        <div class="price-card__price">€425</div>
        <div class="price-card__note">2,5 uur live · ochtend of middag · op maat</div>
        <ul class="price-card__includes">
          <li>Live dagdeel met Anouk</li>
          <li>Lichamelijk én mentaal werk</li>
          <li>Jouw kernovertuiging gevonden en onderzocht</li>
          <li>Concreet vertrekpunt om vrijer te kiezen</li>
          <li>Ochtend of middag, naar keuze</li>
        </ul>
        <a href="https://anoukkievit.membirds.com/checkout/livedag" class="btn btn--coral">Ik boek de dag</a>
      </div>
    </div>
  </div>
</section>


<!-- ═══ ABOUT ═══ -->
<section class="about">
  <div class="w">
    <div class="about__inner">
      <div class="about__photo">
        <div class="about__circles">
          <div class="about__circle-img">
            <img src="https://anoukkievit.nl/wp-content/uploads/2026/06/Anouk-Kievit_Kramer-Fotografeert-0782.jpg" alt="Anouk Kievit" />
          </div>
        </div>
      </div>
      <div>
        <span class="eyebrow eyebrow--coral">Even voorstellen</span>
        <span class="about__sig">Anouk Kievit</span>
        <h2>Hoi,<br>ik ben <em>Anouk.</em></h2>
        <p>Ik leefde jarenlang alsof één gedachte de waarheid was. Het stuurde alles — wat ik at, hoe ik mezelf zag, wat ik toeliet en wat ik mezelf ontzegde. Het voelde zo echt dat ik nooit op het idee kwam het te bevragen. Het was gewoon zo.</p>
        <p>Pas toen ik hem durfde onderzoeken, veranderde er iets wat ik niet meer terug wil draaien. Niet door er harder aan te werken, niet door er meer over na te denken — maar door te stoppen met hem als de waarheid te behandelen.</p>
        <div class="about__pullquote">
          Ik ga niemand vertellen wat ze moeten doen voordat we begrijpen wat ze zichzelf al jaren vertellen.
        </div>
        <p>Ik werk met ondernemers die klaar zijn om eerlijk te kijken naar wat er werkelijk speelt — niet met mensen die nog aan het overwegen zijn. Dat verschil voel ik meteen, en het bepaalt alles.</p>
        <p style="margin-top:28px;"><a href="#investering" class="btn btn--coral">Boek jouw plek</a></p>
      </div>
    </div>
  </div>
</section>


<!-- ═══ FAQ ═══ -->
<section class="faq">
  <div class="w">
    <div style="text-align:center;margin-bottom:60px;">
      <span class="eyebrow eyebrow--blue">Vragen</span>
      <h2>Misschien vraag<br><em>jij je af…</em></h2>
    </div>
    <div class="faq__grid">
      <div>
        <div class="faq__item">
          <div class="faq__q">Ik heb al zoveel geprobeerd. Waarom zou dit anders zijn?</div>
          <div class="faq__a">Omdat de meeste aanpakken werken aan je gedrag, je strategie of je mindset — en dat is precies waarom je blijft zoeken. Wij gaan naar de laag daarvoor: de overtuiging die onzichtbaar alles stuurt. Dat is het verschil, en het is ook de reden dat het voor het eerst voelt alsof je bij de kern bent.</div>
        </div>
        <div class="faq__item">
          <div class="faq__q">Sessie of dag: hoe weet ik wat bij mij past?</div>
          <div class="faq__a">De sessie is direct en krachtig — in één gesprek zie je wat er speelt en heb je een concreet vertrekpunt. De dag biedt meer ruimte en diepgang, ook lichamelijk, voor wat echt tijd nodig heeft om te landen. Als je twijfelt, kies de dag.</div>
        </div>
        <div class="faq__item">
          <div class="faq__q">Werkt dit ook als ik al veel aan mezelf heb gewerkt?</div>
          <div class="faq__a">Juist dan. De ondernemers die ik spreek hebben bijna altijd al veel gedaan — en dat is precies waarom ze voelen dat er nog een laag is. Die laag is wat we hier gaan onderzoeken.</div>
        </div>
      </div>
      <div>
        <div class="faq__item">
          <div class="faq__q">Wat als ik me er nog niet klaar voor voel?</div>
          <div class="faq__a">"Klaar voelen" is precies het soort gedachte dat we hier gaan onderzoeken. Je hoeft je niet klaar te voelen — je hoeft alleen eerlijk te zijn en bereid om te kijken naar wat er werkelijk speelt.</div>
        </div>
        <div class="faq__item">
          <div class="faq__q">Heb ik nog vragen voor ik boek?</div>
          <div class="faq__a">Stel ze gerust. Mail of DM me — geen verkoopgesprek, geen druk, gewoon een eerlijk antwoord op wat je wilt weten.</div>
        </div>
        <div class="faq__item">
          <div class="faq__q">Is er ook een optie voor langdurige samenwerking?</div>
          <div class="faq__a">Ja. Voor wie na de sessie verder wil gaan, is er de mogelijkheid voor een langer traject. Ik ben daarin selectief — niet omdat ik moeilijk wil doen, maar omdat goede begeleiding vraagt om een echte klik. Daarom begin ik altijd met een gratis kennismakingsgesprek. <a href="https://calendly.com/anoukkievit/call" style="color:var(--coral);text-decoration:none;font-weight:600;">Plan hier jouw gratis gesprek →</a></div>
        </div>
      </div>
    </div>
  </div>
</section>


<!-- ═══ FINAL CTA — photo bg ═══ -->
<section class="final-cta" id="contact">
  <div class="final-cta__bg"></div>
  <div class="final-cta__content">
    <h2>Als je voelt dat dit<br>het is —<br><em>dan is dit het moment.</em></h2>
    <p>Mensen die nog twijfelen of hier wat voor hen in zit: dit is waarschijnlijk niet voor jou. Ondernemers die voelen dat er nu iets moet veranderen en klaar zijn om eerlijk te kijken — boek jouw plek.</p>
    <a href="#investering" class="btn btn--coral">Ik wil dit doorbreken →</a>
  </div>
</section>

<footer>
  <p>© 2025 Anouk Kievit</p>
</footer>

</body>
</html>
